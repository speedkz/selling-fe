export interface IFormProduct {
  name: string
  price: string
}
