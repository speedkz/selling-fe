export interface FormState {
  username: string
  password: string
  remember: boolean
}
