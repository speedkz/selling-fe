import resourceService from './resource'

const services = {
  resourceService
}
export default services
