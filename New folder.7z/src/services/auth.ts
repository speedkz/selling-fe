import type { IUser } from '@/models/user'
import $axios from './axiosInstance'

const productService = {
  getCurrentUser: async (): Promise<{
    data: IUser | null
    error: unknown | null
  }> => {
    try {
      const { data } = await $axios.get<IUser[]>('users')
      return {
        data: data[0],
        error: null
      }
    } catch (error) {
      return {
        data: null,
        error
      }
    }
  }
}

export default productService
