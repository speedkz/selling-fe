import axios from 'axios'

const $axios = axios.create({
  baseURL: 'https://api.fake-rest.refine.dev/',
  headers: {
    'Content-Type': 'application/json',
    timeout: 10000
  }
})
export default $axios
