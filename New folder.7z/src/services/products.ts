import { type Product } from '@/models/product'
import $axios from './axiosInstance'

const productService = {
  getList: async (): Promise<{
    data: Product[] | null
    error: unknown | null
  }> => {
    try {
      const { data } = await $axios.get<Product[]>('products')
      return {
        data,
        error: null
      }
    } catch (error) {
      return {
        data: null,
        error
      }
    }
  },
  getOne: async (
    id: string
  ): Promise<{
    data: Product | null
    error: unknown | null
  }> => {
    try {
      const { data } = await $axios.get<Product[]>('products', {
        params: { id }
      })
      return {
        data: data[0],
        error: null
      }
    } catch (error) {
      return {
        data: null,
        error
      }
    }
  },
  saveOne: async (
    id: string,
    payload: Product
  ): Promise<{
    data: Product | null
    error: unknown | null
  }> => {
    try {
      const { data } = await $axios.put<Product>('products', payload, {
        params: { id }
      })
      return {
        data: data,
        error: null
      }
    } catch (error) {
      return {
        data: null,
        error
      }
    }
  }
}

export default productService
