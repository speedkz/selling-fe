<template>
  <Form v-slot="{ handleSubmit }" class="grid gap-8" ref="formRef">
    <div v-for="{ as, name, label, children, ...attrs } in fields" :key="name">
      <label class="mb-2 opacity-40" :for="name">{{ label }}</label>
      <Field :as="as || 'a-input'" :id="name" :name="name" v-bind="attrs">
        <template v-if="children && children.length">
          <component
            v-for="({ tag, text, ...childAttrs }, idx) in children"
            :key="idx"
            :is="tag"
            v-bind="childAttrs"
          >
            {{ text }}
          </component>
        </template>
      </Field>
      <ErrorMessage :name="name" />
    </div>
    <slot name="action" :handleSubmit="handleSubmit"></slot>
  </Form>
</template>
<script lang="ts" setup>
import { Form, Field, ErrorMessage, type FormActions } from 'vee-validate'
import { ref, type PropType } from 'vue'

export interface IField {
  label: string
  name: string
  as?: string
  rules?: any
  children?: any
}

export interface IFormRef {
  formRef: FormActions<any, any>
}
defineProps({
  fields: {
    type: Array as PropType<IField[]>,
    default: () => []
  },
  initialValues: {
    type: Object,
    default: () => {}
  }
})

const formRef = ref(null)

defineExpose({
  formRef
})
</script>
