<script setup lang="ts">
import { provide } from 'vue'
import { RouterView } from 'vue-router'
import type { IUser } from './models/user'
import services from './services'

const { data } = services.resourceService<IUser>('users').getOne('1')
provide('currentUser', data)
</script>

<template>
  <RouterView />
</template>

<style scoped></style>
