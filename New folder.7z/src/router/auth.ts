import type { RouteRecordRaw } from 'vue-router'

const authRoutes: Readonly<RouteRecordRaw[]> = [
  {
    path: '/auth',
    redirect: 'auth/signin',
    children: [
      {
        path: 'signin',
        component: () => import('@/views/auth/SignIn.vue')
      }
    ]
  }
]

export default authRoutes
